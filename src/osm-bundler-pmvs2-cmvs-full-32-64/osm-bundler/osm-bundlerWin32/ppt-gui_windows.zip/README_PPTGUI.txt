-------------------------------------------
WHAT IS PYTHON PHOTOGRAMMETRY TOOLBOX GUI?
-------------------------------------------

This GUI was created by Alessandro and Luca Bezzi using PyQT4.
It is a free software released under the GNU General Public License.


-------------------------------------------
CONTACTS
-------------------------------------------

alessandro.bezzi@arc-team.com
luca.bezzi@arc-team.com
